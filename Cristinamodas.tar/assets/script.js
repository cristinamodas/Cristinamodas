let produtos = [];

// Carrega os produtos do JSON
async function carregarProdutos() {
    try {
        const resposta = await fetch('/data/products.json');
        produtos = await resposta.json();
        exibirProdutos('todos');
    } catch (erro) {
        console.error('Erro ao carregar produtos:', erro);
        document.getElementById('produtos-container').innerHTML = 
            '<p style="text-align:center">Nenhum produto cadastrado ainda. Acesse /admin para começar.</p>';
    }
}

// Exibe produtos filtrados por categoria
function exibirProdutos(categoria) {
    const container = document.getElementById('produtos-container');
    
    let produtosFiltrados = produtos;
    if (categoria !== 'todos') {
        produtosFiltrados = produtos.filter(p => p.categoria === categoria);
    }
    
    if (produtosFiltrados.length === 0) {
        container.innerHTML = '<p style="text-align:center">Nenhum produto nesta categoria.</p>';
        return;
    }
    
    container.innerHTML = produtosFiltrados.map(produto => `
        <div class="produto-card">
            <img src="${produto.imagem || 'https://via.placeholder.com/300x300?text=Sem+Imagem'}" alt="${produto.nome}">
            <div class="info">
                <h3>${produto.nome}</h3>
                <div class="categoria">${produto.categoria}</div>
                <div class="preco">R$ ${produto.preco.toFixed(2)}</div>
                <p>${produto.descricao || ''}</p>
            </div>
        </div>
    `).join('');
}

// Filtro por categoria
document.querySelectorAll('.categoria-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.categoria-btn').forEach(b => b.classList.remove('ativo'));
        btn.classList.add('ativo');
        exibirProdutos(btn.dataset.categoria);
    });
});

// Inicia
carregarProdutos();
